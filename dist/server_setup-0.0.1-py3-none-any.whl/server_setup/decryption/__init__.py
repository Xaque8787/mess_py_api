from .decrypt_pass import decrypt_password

__all__ = ['decrypt_password']
