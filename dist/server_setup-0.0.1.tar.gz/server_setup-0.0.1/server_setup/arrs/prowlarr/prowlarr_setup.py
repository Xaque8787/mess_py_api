from server_setup.arrs.prowlarr.prowlarr_api import *


def main():
    post_indexer()


if __name__ == "__main__":
    main()
