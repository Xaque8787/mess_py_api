import os
from dotenv import load_dotenv
import requests


def get_radarr_headers():
    """
    Load Radarr API details from a .env file and return the necessary headers for API requests.

    Returns:
        dict: A dictionary containing headers and the Radarr API URL.
    """
    # Load environment variables from .env
    load_dotenv()

    # Fetch Radarr details from environment variables
    radarr_ip = os.getenv("RADARR_IP")
    radarr_port = os.getenv("RADARR_PORT")
    radarr_apikey = os.getenv("RADARR_APIKEY")

    if not all([radarr_ip, radarr_port, radarr_apikey]):
        raise ValueError("One or more required environment variables (radarr_ip, radarr_port, radarr_apikey) are missing.")

    # Construct the Radarr API base URL
    base_url = f"http://{radarr_ip}:{radarr_port}/api/v3"

    # Return headers and base URL
    return {
        "base_url": base_url,
        "headers": {
            "X-Api-Key": radarr_apikey,
            "Content-Type": "application/json"
        }
    }


def get_download_clients():
    config = get_radarr_headers()
    response = requests.get(f"{config['base_url']}/downloadclient", headers=config['headers'])
    response.raise_for_status()
    return response.json()

def post_download_client():
    """
    Posts a hardcoded download client configuration to the Radarr API.
    """
    # Get Radarr headers and base URL
    radarr_config = get_radarr_headers()
    url = f"{radarr_config['base_url']}/downloadclient"
    headers = radarr_config['headers']

    # Hardcoded JSON payload
    payload = {
        "id": 0,
        "enable": True,
        "protocol": "torrent",
        "priority": 1,
        "removeCompletedDownloads": True,
        "removeFailedDownloads": True,
        "name": "qBittorrentx12",
        "fields": [
            {
                "order": 0,
                "name": "host",
                "label": "Host",
                "value": "172.22.0.11",
                "type": "textbox",
                "advanced": False,
                "privacy": "normal",
                "isFloat": False
            },
            {
                "order": 1,
                "name": "port",
                "label": "Port",
                "value": 8484,
                "type": "textbox",
                "advanced": False,
                "privacy": "normal",
                "isFloat": False
            },
            {
                "order": 2,
                "name": "useSsl",
                "label": "Use SSL",
                "helpText": "Use a secure connection. See Options -> Web UI -> 'Use HTTPS instead of HTTP' in qBittorrent.",
                "value": False,
                "type": "checkbox",
                "advanced": False,
                "privacy": "normal",
                "isFloat": False
            },
            {
                "order": 3,
                "name": "urlBase",
                "label": "URL Base",
                "helpText": "Adds a prefix to the qBittorrent url, such as http://[host]:[port]/[urlBase]/api",
                "type": "textbox",
                "advanced": True,
                "privacy": "normal",
                "isFloat": False
            },
            {
                "order": 4,
                "name": "username",
                "label": "Username",
                "value": "http://172.22.0.5:7878",
                "type": "textbox",
                "advanced": False,
                "privacy": "userName",
                "isFloat": False
            },
            {
                "order": 5,
                "name": "password",
                "label": "Password",
                "value": headers["X-Api-Key"],  # Replace password with Radarr API key
                "type": "password",
                "advanced": False,
                "privacy": "password",
                "isFloat": False
            },
            {
                "order": 6,
                "name": "movieCategory",
                "label": "Category",
                "helpText": "Adding a category specific to Radarr avoids conflicts with unrelated non-Radarr downloads. Using a category is optional, but strongly recommended.",
                "value": "movie-radarr",
                "type": "textbox",
                "advanced": False,
                "privacy": "normal",
                "isFloat": False
            },
            {
                "order": 7,
                "name": "movieImportedCategory",
                "label": "Post-Import Category",
                "helpText": "Category for Radarr to set after it has imported the download. Radarr will not remove torrents in that category even if seeding finished. Leave blank to keep same category.",
                "type": "textbox",
                "advanced": True,
                "privacy": "normal",
                "isFloat": False
            }
        ],
        "implementationName": "qBittorrent",
        "implementation": "QBittorrent",
        "configContract": "QBittorrentSettings",
        "infoLink": "https://wiki.servarr.com/radarr/supported#qbittorrent",
        "tags": []
    }

    # Make the POST request
    response = requests.post(url, json=payload, headers=headers)

    # Handle the response
    if response.status_code == 201:
        print("Download client configuration successfully added.")
    else:
        print(f"Failed to add download client: {response.status_code} - {response.text}")


if __name__ == "__main__":
    #download_clients = get_download_clients()
    #print(download_clients)
    post_download_client()

